import React, { Component } from 'react';
import FontAwesomeIcon from '@fortawesome/react-fontawesome';
//import './bootstrap.min.css'

import './css/menu.css';

class Nav extends Component {
  render() {
    return (
<header>
        <nav class="cd-stretchy-nav add-content">
         <a class="cd-nav-trigger" href="#0">
            
            <span aria-hidden="true"></span>
          </a>
          
          <ul>
          <li><a href="/"><span>Home</span></a></li>
            <li><a href="/dosa"><span>Dosa</span></a></li>
            <li><a href="/continental"><span>Continental</span></a></li>
            <li><a href="/chinese"><span>Chinese</span></a></li>
           
          </ul>
      
          <span aria-hidden="true" class="stretchy-nav-bg"></span>
        </nav>
      </header>
    );
  }
}

export default Nav;
