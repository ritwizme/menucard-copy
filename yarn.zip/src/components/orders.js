import React, { Component } from 'react';
//import './bootstrap.min.css'
import './css/menu.css';


class Order extends Component {
  render() {
    return (
      
        <div class="order col-md-offset-6 shadow"> 
        </div>


    );
  }
}

export default Order;
