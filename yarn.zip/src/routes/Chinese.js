import React, { Component } from 'react';
import Menu from '../components/menu.js';
import Menu2 from '../components/menu2.js';
//import './bootstrap.min.css';
import {Animated} from "react-animated-css";


class Chinese extends Component {
  render() {
    return (
      <div id="two">
      <Animated animationIn="bounceInLeft" animationOut="fadeOut" isVisible={true}>
      <Menu2 name="Chinese"/>
      </Animated>
      </div>
     
    );
  }
}

export default Chinese;
