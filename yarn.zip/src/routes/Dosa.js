import React, { Component } from 'react';
import Menu from '../components/menu.js';
//import './bootstrap.min.css';
import {Animated} from "react-animated-css";
//import ReactCSSTransitionGroup from 'react-addons-css-transition-group';import './bootstrap.min.css'


class Dosa extends Component {
  componentWillMount(){
    //this.props.history.push('/dosa?id')
  }
  render() {
    return (
      
<div id="one">
<Animated animationIn="bounceInLeft" animationOut="fadeOut" isVisible={true}>

<Menu name="Dosa"/>
</Animated>
</div>

    );
  }
}

export default Dosa;
